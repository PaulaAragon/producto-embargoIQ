<?php
class modelo1
{
	public $u2;
	public $c2;
	
	public function modelo1($u1,$c1)
	{
		$this->u2=$u1;
		$this->c2=$c1;
	}
	
	public function setu2($u1)
	{
		$this->u2=$u1;
	}
	public function getu2()
	{
		return $this->u2;		
	}
	public function setc2($c1)
	{
		$this->c2=$c1;
	}
	public function getc2()
	{	
		return $this->c2;
	}
}
class modelo2
	{	
		public $D1;
		public $R1;
		public $N1;
		public $T1;
		public $A1;
		public $U1;
		public $C1;
	
public function modelo2($D,$N,$A,$U,$C,$T,$R)
	{
		$this->D1=$D;
		$this->N1=$N;
		$this->A1=$A;
		$this->U1=$U;
		$this->C1=$C;
		$this->T1=$T;
		$this->R1=$R;	
	}
		public function setD1($D)
		{
			$this->D1=$D;
		}
		public function getD1()
		{
			return $this->D1;
		}
		//////
		public function setN1($N)
		{
			$this->N1=$N;
		}
		public function getN1()
		{
			return $this->N1;
		}
		//////
		public function setA1($A)
		{
			$this->A1=$A;
		}
		public function getA1()
		{
			return $this->A1;
		}
		///////
		public function setU1($U)
		{
			$this->U1=$U;
		}
		public function getU1()
		{
			return $this->U1;
		}
		/////
		public function setC1($C)
		{
			$this->C1=$C;
		}
		public function getC1()
		{
			return $this->C1; 
		}
		//////
		public function setT1($T)
		{
			$this->T1=$T;
		}
		public function getT1()
		{
			return $this->T1;
		}
		//////
		public function setR1($R)
		{
			$this->R1=$R;
		}
		public function getR1()
		{
			return $this->R1;
		}
		///////
	}
class Modelo3
{
	public  $CEDULA11;
	public function Modelo3($cedula11)
	{
	$this->CEDULA11=$cedula11;
	}
	public function setCEDULA11($cedula11)
	{
	$this->CEDULA11=$cedula11;
	}
	public function getCEDULA11()
	{
	return $this->CEDULA11;
	}
}
class Modelo4
{ 	
	public $AA1;public $BB1;public $CC1;public $DD1;public $EE1;public $FF1;public $GG1;public $HH1;public $II1;public $JJ1;public $KK1;public $LL1;public $MM1;public $NN1;public $NN2;public $OO1;public $PP1;public $QQ1;public $RR1;public $SS1;public $TT1;public $UU1;public $VV1;public $WW1;public $XX1;public $YY1;public $ZZ1;public $AA2;
	
	
	public function Modelo4($A2,$A1,$B1,$C1,$D1,$E1,$F1,$G1,$H1,$I1,$J1,$K1,$L1,$M1,$N1,$N2,$O1,$P1,$Q1,$R1,$S1,$T1,$U1,$V1,$W1,$X1,$Y1,$Z1)
	{
		$this->AA2=$A2;
		$this->AA1=$A1;
		$this->BB1=$B1;
		$this->CC1=$C1;
		$this->DD1=$D1;
		$this->EE1=$E1;
		$this->FF1=$F1;
		$this->GG1=$G1;
		$this->HH1=$H1;
		$this->II1=$I1;
		$this->JJ1=$J1;
		$this->KK1=$K1;
		$this->LL1=$L1;
		$this->MM1=$M1;
		$this->NN1=$N1;
		$this->NN2=$N2;
		$this->OO1=$O1;
		$this->PP1=$P1;
		$this->QQ1=$Q1;
		$this->RR1=$R1;
		$this->SS1=$S1;
		$this->TT1=$T1;
		$this->UU1=$U1;
		$this->VV1=$V1;
		$this->WW1=$W1;
		$this->XX1=$X1;
		$this->YY1=$Y1;
		$this->ZZ1=$Z1;
	}
	public function setAA2($A2)
	{
	$this->AA2=$A2;
	}
	public function getAA2()
	{
	return $this->AA2;
	}
	###########
	public function setAA1($A1)
	{
	$this->AA1=$A1;
	}
	public function getAA1()
	{
	return $this->AA1;
	}
	###########
	public function setBB1($B1)
	{
	$this->BB1=$B1;
	}
	public function getBB1()
	{
	return $this->BB1;
	}
	###########
	public function setCC1($C1)
	{
	$this->CC1=$C1;
	}
	public function getCC1()
	{
	return $this->CC1;
	}
	###########
	public function setDD1($D1)
	{
	$this->DD1=$D1;
	}
	public function getDD1()
	{
	return $this->DD1;
	}
	###########
	public function setEE1($E1)
	{
	$this->EE1=$E1;
	}
	public function getEE1()
	{
	return $this->EE1;
	}
	###########
	public function setFF1($F1)
	{
	$this->FF1=$F1;
	}
	public function getFF1()
	{
	return $this->FF1;
	}
	###########
	public function setGG1($G1)
	{
	$this->GG1=$G1;
	}
	public function getGG1()
	{
	return $this->GG1;
	}
	###########
	public function setHH1($H1)
	{
	$this->HH1=$H1;
	}
	public function getHH1()
	{
	return $this->HH1;
	}
	###########
	public function setII1($I1)
	{
	$this->II1=$I1;
	}
	public function getII1()
	{
	return $this->II1;
	}
	###########
	public function setJJ1($J1)
	{
	$this->JJ1=$J1;
	}
	public function getJJ1()
	{
	return $this->JJ1;
	}
	###########
	public function setKK1($K1)
	{
	$this->KK1=$K1;
	}
	public function getKK1()
	{
	return $this->KK1;
	}
	###########
	public function setLL1($L1)
	{
	$this->LL1=$L1;
	}
	public function getLL1()
	{
	return $this->LL1;
	}
	###########
	public function setMM1($M1)
	{
	$this->MM1=$M1;
	}
	public function getMM1()
	{
	return $this->MM1;
	}
	###########
	public function setNN1($N1)
	{
	$this->NN1=$N1;
	}
	public function getNN1()
	{
	return $this->NN1;
	}
	###########
	public function setNN2($N2)
	{
	$this->NN2=$N2;
	}
	public function getNN2()
	{
	return $this->NN2;
	}
	###########
	public function setOO1($O1)
	{
	$this->OO1=$O1;
	}
	public function getOO1()
	{
	return $this->OO1;
	}
	###########
	public function setPP1($P1)
	{
	$this->PP1=$P1;
	}
	public function getPP1()
	{
	return $this->PP1;
	}
	###########
	public function setQQ1($Q1)
	{
	$this->QQ1=$Q1;
	}
	public function getQQ1()
	{
	return $this->QQ1;
	}
	###########
	public function setRR1($R1)
	{
	$this->RR1=$R1;
	}
	public function getRR1()
	{
	return $this->RR1;
	}
	###########
	public function setSS1($S1)
	{
	$this->SS1=$S1;
	}
	public function getSS1()
	{
	return $this->SS1;
	}
	###########
	public function setTT1($T1)
	{
	$this->TT1=$T1;
	}
	public function getTT1()
	{
	return $this->TT1;
	}
	###########
	public function setUU1($U1)
	{
	$this->UU1=$U1;
	}
	public function getUU1()
	{
	return $this->UU1;
	}
	###########
	public function setVV1($V1)
	{
	$this->VV1=$V1;
	}
	public function getVV1()
	{
	return $this->VV1;
	}
	###########
	public function setWW1($W1)
	{
	$this->WW1=$W1;
	}
	public function getWW1()
	{
	return $this->WW1;
	}
	###########
	public function setXX1($X1)
	{
	$this->XX1=$X1;
	}
	public function getXX1()
	{
	return $this->XX1;
	}
	###########
	public function setYY1($Y1)
	{
	$this->YY1=$Y1;
	}
	public function getYY1()
	{
	return $this->YY1;
	}
	###########
	public function setZZ1($Z1)
	{
	$this->ZZ1=$Z1;
	}
	public function getZZ1()
	{
	return $this->ZZ1;
	}
	###########
}
?>